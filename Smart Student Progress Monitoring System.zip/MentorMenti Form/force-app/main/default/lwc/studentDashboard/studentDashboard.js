import { LightningElement, wire } from 'lwc';
import getDashboardData from '@salesforce/apex/StudentDashboardController.getDashboardData';

export default class StudentDashboard extends LightningElement {

    totalStudents = 0;
    goodStudents = 0;
    lowStudents = 0;

    @wire(getDashboardData)
    wiredData({ error, data }) {
        if (data) {
            this.totalStudents = data.total;
            this.goodStudents = data.good;
            this.lowStudents = data.low;
        } else if (error) {
            console.error(error);
        }
    }
}